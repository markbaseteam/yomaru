Yomaru is my online nickname. Most friends call me Man Lung, which is my actual name.

A professional software engineer. Mainly using Typescript, Next.js and Expo. Currently Team Lead at **Wemakeapp**.

--- 

Always passionate in what I am doing. Keep learning and growing in all aspects.

> Remembering that you are going to die is the best way I know to avoid the trap of thinking you have something to lose. You are already naked. There is no reason not to follow your heart. — Steve Jobs

Have high standard. Create production level products. Focus on the goal. "Simple, loveable, complete" is my rule of thumb in product management.

Advocate of open source, open heart and open mind. Ultimate goal is to work in GitHub. Help shape a better modern society on top of code.

As a Christian, humbly experiencing the excitement of youth. Staying hopeful, positive and brave. Learning how to love and be loved.

Being an instinctive learner, I can identify my true needs, create precise plans and pursue them with passion somehow instinctively. Never stop learning and be mindful that I still have a bigger mission to fulfil.